<?php

//development
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$database = "sentiment_analysis";

//Production
// $host = "localhost";
// $dbusername = "babbimmn_babbage";
// $dbpassword = "rTNz[pb1NI,G";
// $database = "babbimmn_vidimpact";

