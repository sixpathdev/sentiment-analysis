function submitform(str){
    $(`#${str}`).trigger('submit');
}
